export default function bar() {
    //
}