import bar from './bar';

bar();